<x-layouts.app title="Masuk">
    <div class="mx-auto max-w-md mt-20">
        <div class="mb-8 text-center">
            <h1 class="text-2xl font-semibold">Masuk ke TMMS-SCPK</h1>
            <p class="text-sm text-gray-600 mt-1">Gunakan email & kata sandi akunmu.</p>
        </div>

        <div class="rounded-2xl bg-white p-6 shadow-sm border border-gray-200">
            <form action="{{ route('login.store') }}" method="POST" class="space-y-4">
                @csrf
                <div>
                    <label class="block text-sm font-medium mb-1" for="email">Email</label>
                    <input id="email" name="email" type="email" value="{{ old('email') }}" required autofocus
                        class="w-full rounded-xl border-2 border-gray-500 focus:border-gray-900 focus:ring-gray-900" />
                    @error('email')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1" for="password">Kata Sandi</label>
                    <input id="password" name="password" type="password" required
                        class="w-full rounded-xl border-2 border-gray-500  focus:border-gray-900 focus:ring-gray-900" />
                    @error('password')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="flex items-center justify-between">
                    <label class="inline-flex items-center gap-2 text-sm">
                        <input type="checkbox" name="remember" value="1"
                            class="rounded border-gray-300 text-gray-900 focus:ring-gray-900" />
                        Remember me
                    </label>
                    {{-- Opsional: tautan lupa password --}}
                    {{-- <a href="#" class="text-sm text-gray-700 hover:underline">Lupa password?</a> --}}
                </div>

                <button type="submit"
                    class="w-full rounded-xl bg-gray-900 text-white py-2.5 font-medium">Masuk</button>
            </form>
        </div>
    </div>
</x-layouts.app>

<x-layouts.app :title="'Edit Kriteria'">
    <div class="mb-4">
        <a href="{{ route('kriteria.index') }}" class="text-sm text-blue-700 hover:underline">← Kembali</a>
    </div>

    <div class="bg-white rounded-2xl shadow p-5">
        <h1 class="text-lg font-semibold mb-4">Edit Kriteria: {{ $kriteria->kode_kriteria }}</h1>

        <form action="{{ route('kriteria.update', $kriteria) }}" method="POST" id="kriteriaForm">
            @csrf @method('PUT')
            @include('kriteria._form', ['mode' => 'edit', 'kriteria' => $kriteria])
        </form>
    </div>
</x-layouts.app>

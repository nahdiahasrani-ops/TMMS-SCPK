<x-layouts.app :title="'Tambah Kriteria'">
  <div class="mb-4">
    <a href="{{ route('kriteria.index') }}" class="text-sm text-blue-700 hover:underline">← Kembali</a>
  </div>

  <div class="bg-gray-100 rounded-2xl shadow-sm p-5">
    <h1 class="text-lg font-semibold mb-4">Tambah Kriteria</h1>

    <form action="{{ route('kriteria.store') }}" method="POST" id="kriteriaForm">
      @csrf
        @include('kriteria._form', ['mode' => 'create'])
    </form>
  </div>
</x-layouts.app>

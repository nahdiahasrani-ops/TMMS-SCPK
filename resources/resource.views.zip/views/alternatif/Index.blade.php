@include('Layout.Nav')
<x-layouts.app :title="'Data Alternatif & Normalisasi'">
  <div class="mb-4">
    <form method="GET" class="flex items-center gap-3">
      <label class="text-sm">Jabatan</label>
      @php $opt=['Operator','Mekanik','HSSE']; @endphp
      <select name="jabatan" class="border rounded-lg px-3 py-2">
        @foreach($opt as $j)
          <option value="{{ $j }}" {{ $jabatan===$j?'selected':'' }}>{{ $j }}</option>
        @endforeach
      </select>
      <label class="text-sm">Tahun</label>
      <input type="number" name="tahun" value="{{ $tahun }}" class="border rounded-lg px-3 py-2 w-28">
      <button class="rounded-lg border px-3 py-2 hover:bg-gray-50">Terapkan</button>
    </form>
  </div>

  {{-- REKAP ALTERNATIF (AVG per Sub) --}}
  <h2 class="text-xl font-semibold mb-1">Rekap Data Alternatif</h2>
  <p class=" text-sm mb-2">Rekap data alternatif adalah hasil dari rata-rata nilai 12 bulan (1 tahun) dibagi dengan bobot subkriteria.</p>
  <div class="bg-white rounded-md shadow-sm overflow-x-auto mb-8">
    <table class="w-full text-left text-sm">
      <thead class="bg-blue-300">
        <tr>
          <th class="px-4 py-3">Kode</th>
          <th class="px-4 py-3">Nama Karyawan</th>
          <th class="px-4 py-3">Jabatan</th>
            @foreach($subs as $s)
                <th class="px-2 py-3 text-center whitespace-nowrap">
                    {{ $s->kode_sub }}
                    <div class="text-[10px] text-gray-500">w: {{ rtrim(rtrim(number_format($s->bobot*100,2,'.',''),'0'),'.') }}%</div>
                </th>
            @endforeach
        </tr>
      </thead>
      <tbody class="divide-y">
        @forelse ($karyawans as $kar)
          <tr>
            <td class="px-4 py-3 font-medium">{{ $kar->kode }}</td>
            <td class="px-4 py-3">{{ $kar->nama }}</td>
            <td class="px-4 py-3">{{ $kar->jabatan }}</td>
            @foreach($subs as $s)
              <td class="px-2 py-3 text-center">
               {{ is_null($roundedW[$kar->id][$s->id]) ? '–' : round($roundedW[$kar->id][$s->id] * 100, 0) . '%' }}
              </td>
            @endforeach
          </tr>
        @empty
          <tr><td colspan="{{ 3 + $subs->count() }}" class="px-4 py-6 text-center text-gray-500">Tidak ada karyawan.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>

  {{-- NORMALISASI SAW --}}
  <h2 class="text-xl font-semibold mb-1">Normalisasi Alternatif</h2>
    <p class=" text-sm mb-2">Normalisasi alternatif adalah hasil dari rekap alternatif dibagi dengan nilai minimal dan maksimal sesuai tipe subkriteria.</p>

  <div class="bg-white rounded-md shadow-sm overflow-x-auto">
    <table class="w-full text-left text-sm">
      <thead class="bg-blue-300">
        <tr>
          <th class="px-4 py-3">Kode</th>
          <th class="px-4 py-3">Nama Karyawan</th>
          <th class="px-4 py-3">Jabatan</th>
          @foreach($subs as $s)
            <th class="px-2 py-3 text-center whitespace-nowrap">
              {{ $s->kode_sub }}
              <div class="text-[10px] text-gray-500">{{ ucfirst($s->tipe) }}</div>
            </th>
          @endforeach
        </tr>
      </thead>
      <tbody class="divide-y">
        @forelse ($karyawans as $kar)
          <tr>
            <td class="px-4 py-3 font-medium">{{ $kar->kode }}</td>
            <td class="px-4 py-3">{{ $kar->nama }}</td>
            <td class="px-4 py-3">{{ $kar->jabatan }}</td>
            @foreach($subs as $s)
              @php
                $nv = $norm[$kar->id][$s->id];
                $pct = is_null($nv) ? null : ($nv*100);
              @endphp
              <td class="px-2 py-3 text-center">
                {{ is_null($pct) ? '–' : rtrim(rtrim(number_format($pct,2,'.',''), '0'),'.').'%' }}
              </td>
            @endforeach
          </tr>
        @empty
          <tr><td colspan="{{ 3 + $subs->count() }}" class="px-4 py-6 text-center text-gray-500">Tidak ada karyawan.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</x-layouts.app>

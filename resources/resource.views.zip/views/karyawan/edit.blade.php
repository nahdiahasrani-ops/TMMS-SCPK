<x-layouts.app :title="'Edit Karyawan'">
  <div class="mb-4 flex items-center justify-between">
    <a href="{{ route('karyawan.index') }}" class="text-sm text-blue-700 hover:underline">← Kembali</a>
  </div>

  <div class="bg-white rounded-2xl shadow-sm p-5">
    <h1 class="text-lg font-semibold mb-4">Edit Karyawan: {{ $karyawan->nama }}</h1>

    <form action="{{ route('karyawan.update', $karyawan) }}" method="POST">
      @csrf @method('PUT')
      @include('karyawan._form', ['mode' => 'edit', 'karyawan' => $karyawan])
    </form>
  </div>
</x-layouts.app>

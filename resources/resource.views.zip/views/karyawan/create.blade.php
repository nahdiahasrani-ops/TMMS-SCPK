<x-layouts.app :title="'Tambah Karyawan'">
  <div class="mb-4">
    <a href="{{ route('karyawan.index') }}" class="text-sm text-blue-700 hover:underline">← Kembali</a>
  </div>

  <div class="bg-white rounded-2xl shadow-sm p-5">
    <h1 class="text-lg font-semibold mb-4">Tambah Karyawan</h1>

    <form action="{{ route('karyawan.store') }}" method="POST">
      @csrf
      @include('karyawan._form', ['mode' => 'create'])
    </form>
  </div>
</x-layouts.app>
